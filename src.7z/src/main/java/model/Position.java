package model;

public class Position {
    private String name;
    private int minAge;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMinAge() {
        return minAge;
    }

    public void setMinAge(int minimalAge) {
        this.minAge = minimalAge;
    }
}
